# PogoSkill 台灣 SEO 文章助手

讓同事在自己的 Codex 安裝完整文章流程，每天早上 9 點自主選題並生成一篇台灣繁中文章包。沿用原有五角色分工、歷史查重、產品橋接、內容豐富的結構 Excel、Word 與獨立審核。

**這是 Codex 工作流程套件，需要同事自己的可用帳號與本機工作區。** GitHub 負責分發，不會替同事執行 AI 任務。安裝後需在同事帳號建立排程；早上 9 點是啟動時間，完成後通知。

## 同事最快的安裝方式

下載本倉庫 ZIP 並解壓，在 Codex 開啟解壓後的資料夾，貼上：

> 請讀 README.md，幫我把這套 PogoSkill 文章助手安裝到一個獨立的本地工作區，不覆寫既有檔案。使用 scripts/install.py 建立環境，檢查 Python、必要依賴、繁中字型與 Word 渲染工具。需要歷史總帳時請告訴我放置位置，不用示範資料代替。安裝完開啟工作區並跑 doctor。先告訴我安裝和缺項的真實結果；資料和工具齊備後，再依 docs/setup-daily.md 在我的帳號設定每日台灣時間早上 9 點的完整文章任務。

需要從負責人取得最新版 `PoGoskillTW-文章上线记录.xlsx`，放到安裝輸出的工作區根目錄。**總帳不在 GitHub 發行包中**，請透過團隊內部管道取得。資料可能隨時變動，日後仍需同步最新版；同事之間的待寫題目也要寫回共用規劃表，避免各自重複立項。

## 手動安裝

準備 Python 3.9+、自己的 Codex、可用網路搜尋與子代理能力。從解壓後的倉庫資料夾執行（下例為 macOS／Linux）：

```bash
python3 scripts/install.py --workspace "$HOME/PogoSkill-Writer" --ledger "/path/to/PoGoskillTW-文章上线记录.xlsx"
cd "$HOME/PogoSkill-Writer"
.venv/bin/python scripts/doctor.py
```

Windows 使用 `python scripts/install.py --workspace "%USERPROFILE%\PogoSkill-Writer"`（cmd），後續 Python 為工作區的 `.venv\Scripts\python.exe`；也可以透過 Codex 依當前 shell 產生正確指令。未提供 `--ledger` 時可先安裝，再把真實總帳放進工作區。安裝器拒絕非空工作區，不會改寫全域 Codex 設定或原有排程。安裝中斷時，保留錯誤資訊並選新的空資料夾重新安裝，原資料不會被刪除。

已具備依賴的受管理 runtime 可加 `--skip-deps`；之後用該 runtime 執行所有腳本，不會自動建立 `.venv`。正常安裝會透過 pip 下載 `requirements.txt` 中的 openpyxl 與 python-docx。此套件不包含 API key、不要求複製作者登入憑證，也不寫死模型。

在 Codex 開啟安裝後工作區，確認 `$pogoskill-tw-seo` 可用。若尚未出現，重新開啟該工作區或重啟 Codex。請保留完整工作區；只用通用 skill-installer 複製 SKILL.md 目錄不會安裝本倉庫外層工具和排程指引。

總帳若來自 WPS，可能有 openpyxl 無法載入的樣式；已提供 `scripts/read_ledger.py`，直接只讀解析所有工作表的真實儲存格與超連結，不改動原始 Excel。使用 `.venv/bin/python scripts/read_ledger.py PoGoskillTW-文章上线记录.xlsx --output data/ledger.json`。數字／日期保持原始值，公式不重新計算；查重時仍需讀完整資料並核對實際舊頁，不能只看名稱。

## 每日設定

依 [每日設定指引](docs/setup-daily.md) 手動試跑後，在同事自己的 Codex 建立每日任務。正式提示詞在 [automation-prompt.md](automation-prompt.md)。完成設定後，必須看到任務已啟用和下次執行時間，不能把「安裝成功」當成「排程成功」。

排程依 [OpenAI Docs](https://learn.chatgpt.com/docs/automations?surface=app) 的本機專案模式執行：電腦開機、應用程式執行、工作區與資料保持可存取。通知在 Codex 中，沒有預設郵件寄送，也不自動發布 CMS。

## 每次產物

```text
runs/YYYY-MM-DD/topic-slug/
  01-research.md
  02-seo-strategy.md
  03-content-brief.md
  03-article-structure.xlsx
  04-draft.md
  04-article.docx
  05-review.md
  06-reflection.md
```

內容約 3,000 個中文字，一天一篇可為 UPDATE；不強制建立新 URL。缺歷史總帳不能宣稱完成查重。Writer 與 Reviewer 以正式檔案交接，Reviewer 同時檢查策略、Brief、Excel、Draft，問題修正後再審。僅獨立審核 PASS、事實完整且 Word 視覺 QA 完成才可稱 Ready to Publish。即使資料不足或當天任務失敗，也應保存已完成產物並回報阻塞。

## Excel、Word 與渲染

以工作區 `.venv` 的 Python 執行：

```bash
.venv/bin/python scripts/export_structure.py outline.json runs/2026-10-15/example/03-article-structure.xlsx
.venv/bin/python scripts/export_docx.py runs/2026-10-15/example/04-draft.md
.venv/bin/python scripts/render_docx.py runs/2026-10-15/example/04-article.docx
```

`outline.json` 由 Architect 產生，是非空字串組成的三欄陣列：

```json
[["H2", "這節的實際標題", "這節實際準備表達的已核驗內容、步驟與限制；不能只寫撰稿指令。"]]
```

Excel 工具保留原始模板，寫入副本。Word 工具完整處理當前 Markdown 的標題、段落、清單、簡單表格、粗體和超連結，並保存來源／Word SHA-256。複雜 Markdown、內嵌圖片或 HTML 應先擴充轉換工具，不能靜默省略內容。建置紀錄預設 `visual_qa: NOT_PERFORMED`，不能當成內容審核通過。

渲染優先使用可用 documents skill 的工具；本包另提供 LibreOffice＋Poppler 的可攜式替代方案。請從官方來源或系統可信套件管理器安裝這兩項，並確保可用繁中字型（例如微軟正黑體、蘋方-繁或 Noto Sans CJK TC）。Word 轉換可用 `--font` 指定已安裝字型。安裝包不會替你自動下載大型渲染工具。每次必須逐頁檢查 PNG，沒有渲染工具時明確標記待完成 QA。

## 包含與本地資料

包含完整團隊規則、五角色說明、品牌／台灣語言／SEO 標準、兩份研究與寫作提示詞、原始結構 Excel、可攜式安裝與文件工具、每日排程指引。原規範提到但來源專案未提供的其他範例 Excel 和原始內部 Word 文件屬選讀參考，不可假裝已讀；完整抽取規範及正式 `繁中文章结构.xlsx` 已包含。

不包含已寫文章、公司歷史總帳、私密排程檔、登入資料或作者電腦路徑。工作區的 runs、memory、總帳與環境由 `.gitignore` 排除；沒有自動同步或共享鎖，團隊須維護共同總帳。CMS 上傳屬另外的站點助手，這個套件的授權止於文章產物。

規範原文保存在 `.agents/skills/pogoskill-tw-seo/references/`；可攜式例外和每日自主選題的授權邊界，以技能入口的說明為準。原始規範不代表每篇文章都套同樣大綱。
