# 在同事的 Codex 設定每日文章

1. 執行安裝程式並將最新團隊歷史總帳放進工作區根目錄。確認 `doctor.py` 的必要資料檢查通過。
2. 同事登入自己的 Codex，開啟安裝輸出的工作區資料夾。重新載入技能後，以 `$pogoskill-tw-seo` 手動試跑一次，檢查網路搜尋、獨立 Reviewer、Excel、Word 及渲染是否可用。
3. 在**同事的這個工作區對話**貼上以下內容：

> 請使用 $pogoskill-tw-seo，為目前工作區設定每天台灣時間早上 9 點啟動的文章任務，沿用我的可用模型和工具，每天自主選題並完成一篇含結構 Excel、完整 Word 和獨立審核的文章包，完成後在我的 Codex 通知我。請讀取 automation-prompt.md 作為正式任務內容。先查既有排程，同用途就更新，避免重複。以本機工作區執行並保留歷次 runs 和 memory；這是每天獨立的文章工作，請建立獨立排程任務，不要僅在目前聊天設定提醒。成功後顯示任務名稱、Asia/Taipei 時區、下次執行時間與工作區路徑；如果工具不支援某欄位，請告知並以介面完成，不要自行寫入原始排程檔。

4. 到 Codex 的 Automations／Scheduled 頁確認任務存在、已啟用、有效本地時區為台灣 UTC+8；不能把 09:00 換成 UTC 01:00 後填入本地時間欄位。用 Run now 驗證一輪。只有介面／工具確認成功才算已排程。

每天 09:00 是啟動，完成後才通知。若需要 09:00 前收稿，另行設定提早啟動。此套件沒有預設郵件寄送。

本機專案排程執行時，電腦須開機、應用程式運作、工作區與本地資料可存取。下載技能不會把作者的排程移到同事帳號，也不提供雲端常駐執行服務。

依官方文件核對，2026-10-15：
- [OpenAI Docs：Scheduled tasks](https://learn.chatgpt.com/docs/automations?surface=app)
- [OpenAI Docs：Build skills](https://learn.chatgpt.com/docs/build-skills)
