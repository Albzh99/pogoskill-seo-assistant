# User Feedback

## 2026-09-18 — Product bridge and remote-location positioning must be explicit

- Every article must contain a natural, clearly connected PogoSkill recommendation. It cannot be omitted or reduced to a generic end-of-article mention.
- After the product bridge, include executable usage steps: normally 4 steps — download PogoSkill, connect the phone, enable Joystick, and use multi-point movement/route simulation. A 3-step version may combine the last two steps when appropriate.
- For location-limited or remote event articles, do not conclude that the player must physically be in the official event city (for example, Brisbane) in a way that negates the product bridge. Position PogoSkill as a virtual-location/remote participation option that helps players handle the location barrier, while still stating relevant game-rule and account-risk caveats without making unverifiable guarantees.
- This feedback is a global content rule, not only a correction for the current article.
- Product transitions should be short and natural, not dominated by repeated guarantees, prohibitions, or risk disclaimers. For a location problem, directly connect the user's inability to attend in person with “可以使用 PogoSkill 飞过去”，then move into the steps.

## 2026-09-18 — Prefer Chinese throughout the article

- Use Taiwan Traditional Chinese as the default for titles, body copy, instructions, explanations, CTAs, and product bridges.
- Do not add English merely for style or appearance. Retain English only for product/game names, URLs, required SEO keywords, interface labels, or proper nouns without a natural Chinese equivalent; explain them in Chinese at first mention when useful.

## 2026-09-14 — Historical topic overlap must be avoided

- The attached `PoGoskillTW-文章上线记录.xlsx` is the current published-content ledger and has been synced to the project root as `PoGoskillTW-文章上线记录.xlsx`.
- Future proposals must avoid any new article that solves the same topic, player problem, or primary Search Intent as an already published article.
- A different title, synonym, year, question wording, or refreshed list is not enough to justify a new page.
- Topic expansion is allowed only when the expanded topic has a clearly independent user need and content boundary. Example: a basic Pikmin Bloom planting guide and an automatic planting/tool-use guide may coexist, but the second must not repeat the basic planting tutorial or compete for the same intent.
- Overlap should be resolved as `UPDATE`, `MERGE / REDIRECT`, or `REJECT`; `NEW PAGE` requires an explicit non-overlap explanation and URL relationship plan.

## 2026-09-22 — Keyword expansion must be systematic and visible in the article

- Keyword research must follow the logic `seed keyword → search intent → keyword expansion → page structure`, rather than providing a single keyword and a few synonyms.
- Expansion should cover the user's actual dimensions: acquisition/how-to, location/time, object/reward, problem questions, player scenarios, and product-related use cases when relevant.
- The article must visibly reflect the expansion through meaningful H2/H3 sections, tables, steps, and complementary FAQ answers. Do not insert variants mechanically.
- Learn from Ahrefs, Semrush, and Google Search Central guidance: use SERP results and ranking-page clustering to decide whether terms belong to one page or separate intents; record search volume/KD when available and mark unavailable data as `未取得`.
- This is a process requirement for both humans and agents, not a request to stuff keywords into the copy.
