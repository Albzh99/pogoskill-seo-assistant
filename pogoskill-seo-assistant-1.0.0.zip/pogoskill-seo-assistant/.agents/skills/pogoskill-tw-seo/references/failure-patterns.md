# Failure Patterns

## 2026-09-18 — Product bridge was negated by an official-location conclusion

- **Observed:** The article recommended PogoSkill, then stated that the player had to be physically in Brisbane, making the recommendation logically pointless.
- **Cause:** The draft repeated the official event-location requirement without distinguishing the official on-site condition from the user's remote-location problem and PogoSkill's intended use case.
- **Impact:** Broken transition, weak commercial relevance, and a contradiction between the product section and the article conclusion.
- **Prevention:** For location-limited topics, complete the logic chain `player location problem → PogoSkill remote-location solution → limitations/risk caveats → concrete download and setup steps`. Do not present the official venue as the only possible player action when the article's purpose is to explain a remote-location solution.

## 2026-09-20 — Product bridge became too disclaimer-heavy

- **Observed:** The product transition spent too much space explaining what could not be guaranteed, instead of simply showing how PogoSkill solves the player's location problem.
- **Cause:** Safety caveats were allowed to overwhelm the user-facing recommendation.
- **Prevention:** Use one short, natural bridge and proceed to the practical steps. Keep only necessary, concise risk wording.

## 2026-09-14 — New activity wording overlapped an existing bakery decor page

- **Observed:** The daily draft proposed `NEW PAGE` for `Pikmin Bloom 甜點裝飾皮克敏`, but the latest published-content ledger already contained `稀有麵包皮克敏` at `https://tw.pogoskill.com/game-app/pikmin-bloom-bakery-decor-pikmin.html`.
- **Cause:** The initial check treated the new official announcement, new decor name, and new date as enough independent value, without applying the user's stricter same-topic exclusion rule.
- **Impact:** The draft and DOCX initially pointed to a conflicting new URL and were incorrectly marked PASS.
- **Fix:** Reclassified the work as `UPDATE`, changed the target and canonical URL to the existing bakery decor page, downgraded review to `PASS WITH FIXES`, and marked the package as not ready until it is merged with the existing page.
- **Prevention:** Compare the player problem and primary Search Intent against published topics before evaluating freshness. A new announcement can be an update even when it adds new mechanics, dates, or decor names.
