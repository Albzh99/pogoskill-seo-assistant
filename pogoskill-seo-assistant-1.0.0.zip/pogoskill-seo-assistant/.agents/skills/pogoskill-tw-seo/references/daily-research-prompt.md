# Daily research prompt

首先读取 `brand-memory.md`、`tw-content-style.md` 和 `internal-seo-standards.md`。再读取 `PoGoskillTW-文章上线记录.xlsx` 的全部工作表，尤其是实时上线记录、SEO 优化记录、竞品主题及 2024–2026 规划。我们就是 PogoSkill，目标是用 SEO/GEO 抢占有价值关键词，并将相关流量自然导向 GPS location changer、Pokémon GO/Pikmin Bloom 飞人、路线模拟和 AutoCatch 等产品。

主要市场固定为台湾。关键词发现、竞争页面与搜索意图以 Google 台湾和 zh-TW 为准，使用台湾繁体中文与官方台湾译名。为每个题目列出台湾主/次关键词、英文或其他地区变体、推荐用词、应避免用词及台湾 SERP 意图；不得把英文或简体词机械转换为繁体。日期和活动时间换算台湾时间，价格优先 NT$，并说明活动或产品条件是否适用于台湾。

发现选题前先查 Excel 的已上线、已优化、已外包和规划中状态，再读取最新 sitemap，并用站内搜索、URL、title/H1、关键词同义词和搜索意图审计已有内容。随后搜索 Pokémon GO、Pikmin Bloom、GPS/location changer、自动抓宝、定位类游戏及可合理桥接产品的主题。热点是机会来源之一，不是唯一来源。

执行多轮检索：第一轮发现热点；第二轮寻找官方原始公告；第三轮用另一个独立可信来源交叉验证；第四轮核对日期、地区、时区、奖励、角色名称和活动条件。重要事实原则上至少需要 2 个相互独立的来源，其中至少 1 个为官方原始来源。若只有一个来源，标记「单一来源，待核验」且不得列为今日首选题。社交截图、转载和引用同一篇公告的聚合站不算独立来源。

优先来源：Pokémon GO Live、Niantic、Pikmin Bloom 官方站点与官方账号；其次为可信游戏媒体；社区只用于发现趋势，不用于单独确认事实。明确区分已确认信息、合理推断、数据挖掘和传闻。检查事件发生日期而不只看文章发布日期，统一换算台湾时间，并避免重复过时消息。若官方页面暂时不可访问，至少重试并使用官方缓存或官方账号核对；仍无法确认时明确降级，不得补写猜测。

参考文章风格：
- https://tw.pogoskill.com/pokemon-ios/how-to-catch-solgaleo.html
- https://tw.pogoskill.com/pokemon-ios/go-fest-2026-global-guide.html

用繁体中文输出：

1. 一段「今日摘要」。
2. 按 SEO 机会与商业价值排序的 3–5 个选题。每题包含 primary/secondary keywords、cluster、搜索意图、漏斗阶段、需求/趋势证据、产品相关性、转化路径、排名可行性、差异化大纲、primary/secondary CTA 和时效窗口。
3. 对每题执行 cannibalization audit，给出唯一判定：NEW PAGE、UPDATE EXISTING、MERGE/REDIRECT 或 REJECT。列出冲突的真实 URL、意图重叠原因和建议 primary URL。已有页面能覆盖同一意图时禁止推荐新页。
4. 对事实给出原始来源与发布日期；优先官方链接。
5. 推荐已确认存在的 PogoSkill 内链与产品目标页；说明锚文本、插入位置和用户价值，不虚构 URL。进入写作阶段后，每篇正文至少规划 2 个指向 `https://tw.pogoskill.com/` 的主页超链接，以及一段与当前玩家场景自然相关的 PogoSkill 产品桥接；若主题产品相关性弱，使用短的可选说明，不夸大必要性。
5. 列出「今天不建议写」的噪音或低可信传闻及原因。
6. 最后选出唯一一个「今日首选题」，并提供可直接交给写手的 150–250 字 brief。

7. 为每个选题给出完整 visual brief，而不只是图片搜索结果：需要哪些封面、原创信息图/表格、步骤截图、时间轴、地图/坐标图、检查表和产品界面图；每项说明用途、插入位置、数据来源、原始页面、作者、许可、署名、建议尺寸、jpg/webp、文件名、台湾繁体图中文字、caption 和 SEO alt。优先 PogoSkill 自有截图/原创设计、官方许可素材、Wikimedia Commons/明确许可素材。许可不明标记「需取得授权」；禁止复制竞争站图片或伪造产品 UI。检查站内旧图，避免重复或过时视觉。

8. 给出 SEO/GEO 机会：主关键词、次关键词、实体、用户问题、featured snippet 答案角度、AI 引用友好的事实块、建议 schema、E-E-A-T 信号、站内链接锚文本，以及 3–5 个真正相关的 backlink 建议。每项只需说明潜在来源类型或真实页面、相关性、可制作的可链接内容资产，以及自然获得引用的理由。仅供用户决策；不得创建、提交、购买、交换、索取或联络任何反向链接，也不得声称已经获得链接。

如果当天没有足够强的新热点，改为查看未来 14 天活动日历，推荐一个可提前布局的常青或预热选题，并明确说明不是突发热点。

## 每日自主交付（强制）

本任务不等待用户选择题目。完成研究与策略判断后，直接推进唯一「今日首选题」：

1. 建立 `runs/YYYY-MM-DD/topic-slug/`，保存完整 `01-research.md`。
2. 由 SEO Strategist 完成 Historical Content Check、Cannibalization Check 与页面决策，保存 `02-seo-strategy.md`。
3. 由 Content Architect 完成 `03-content-brief.md` 与 `03-article-structure.xlsx`；必须以根目录 `繁中文章结构.xlsx` 为只读模板复制，不得修改原模板。
4. 由 Content Writer 读取上述正式交接文件，并依 `article-production-prompt.md` 撰写正文；**可见正文目标为 2,800–3,200 个中文字符，默认约 3,000 字**。保存 `04-draft.md`。
5. 由 SEO Reviewer 同时审核 strategy、brief、structure 与 draft，保存 `05-review.md`。出现 PASS WITH FIXES 或 FAIL 时，Writer 必须修改并再审，直至 PASS；使用明确的版本号，且标明 Current Draft。
6. 保存 `06-reflection.md`，并在本任务最终回报中直接提供：文章标题、判定（NEW／UPDATE 等）、审核状态、正文字符数、产物路径与最终可发布文章。

每日交付目标是至少一份已审核、可发布的文章包，而不是强制每天新增 URL。若新主题不适合 NEW PAGE，必须自主选择最有价值的 UPDATE 或内容整合方向并完成可发布稿；不得因为等待确认、选题不足或新建 URL 风险而只交付研究报告。

## DOCX 强制交付

从 2026-09-15 起，每次进入 Content Production 的每日任务都必须额外交付：

`runs/YYYY-MM-DD/topic-slug/04-article.docx`

DOCX 必须由当前版本的 `04-draft.md` 生成，不能只把 Markdown 改名或仅输出空壳文件。文档必须包含完整正文、SEO 标题与 H1、表格、FAQ、CTA、来源、正文内链、至少 2 个指向 `https://tw.pogoskill.com/` 的主页超链接，以及 Visual Placeholder、caption 和 alt 说明。若 Draft 迭代为新版本，DOCX 也必须同步重建，不得混用旧版本。

使用 documents skill 的 `render_docx.py` 渲染 DOCX，检查所有页面 PNG 的断页、表格宽度、文字裁切、缺字、链接/占位内容和整体可读性；发现问题必须修正后重新渲染并再次逐页检查。最终回报必须列出 DOCX 绝对路径。`SEO Reviewer` 未达到 `PASS` 时，DOCX 只能标记为审核中，不得标记 `Ready to Publish` 或称为可发布。用户明确取消当天产出时不补做当天文章，但下一次每日任务仍必须执行本要求。
