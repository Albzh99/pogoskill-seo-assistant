# SEO Hypotheses

## 2026-09-22 — Keyword expansion should mirror the user's decision path

- **Observation:** The reference keyword sheet expands one seed topic into location, acquisition, object, problem, reward, and scenario terms.
- **Hypothesis:** For Taiwan game-guide queries, a keyword map based on the player's decision path may produce clearer articles than a list of synonyms.
- **Status:** UNVERIFIED
- **Evidence:** User feedback; Ahrefs keyword research and clustering guidance; Semrush SERP-based clustering guidance; Google Search Central SEO Starter Guide.
- **Next validation:** Apply the map to multiple Pokémon GO and Pikmin Bloom topics, then compare reviewer feedback, Search Console queries, and whether each cluster is fully answered by the assigned section.
