# Article production prompt

首先读取 `brand-memory.md`、`tw-content-style.md` 和 `internal-seo-standards.md`，并查询原始上线记录 Excel 全部工作表。根据选定题目生成可发布到 tw.pogoskill.com 的繁体中文文章包。沿用台湾站既有的标题节奏、编号结构、比较表/步骤/FAQ 和自然产品桥接，但不复制原文或旧事实。写作前同时核对 Excel、最新 sitemap、title/H1、URL、关键词及搜索意图；若已上线、已优化、已外包或规划主题冲突，停止新文章并输出更新/合并/人工确认方案。再次复核所有时效事实。

## 篇幅标准（强制）

- 正文（H1 以下至 CTA／结语、含表格与 FAQ 的可见文字）目标为 **2,800–3,200 个中文字符**；默认以约 3,000 字为准。
- Meta、来源清单、视觉制作包、schema 建议、编辑说明与审核报告不计入正文篇幅。
- 以直接回答、必要步骤、关键限制与 FAQ 为优先；删除重复定义、泛泛背景、同义改写和无助于用户决策的产品铺陈。
- 不得为凑字数增加章节；若事实不足以支撑约 3,000 字，应交付更短但完整、经审核的文章，并在 Editorial Notes 说明原因。

文章面向台湾读者：使用自然台湾繁体中文和台湾官方游戏译名，以 Google 台湾搜索意图决定用词；统一台湾时间（UTC+8）、NT$ 与台湾适用条件。避免中国大陆或港澳特有表达，除非为了比较关键词且明确标注。

输出顺序：

1. 内容 brief：受众、搜索意图、漏斗阶段、主/次关键词、cluster、指定 primary URL、差异化价值和 cannibalization verdict。
   - 在正式 Draft 顶部另列出 `Primary Keyword` 与 `Keyword Expansions`，并标明每个扩展词的自然落位或使用场景。
2. SEO metadata：3 个标题版本（建议不超过约 60 个英数显示字符）、slug、meta description、OG title/description、canonical 建议。
3. 完整原创文章：清晰 H1/H2/H3、开头直接回答、目录、表格/清单、关键日期与台湾时间、实用步骤、常见错误、FAQ、结论和自然 CTA；正文严格遵守约 3,000 字的篇幅标准。禁止关键词堆砌、虚构体验或大段改写来源。
4. 引用：事实旁附原始来源；文末列来源名称、发布日期、页面标题和 URL。注明文章最后核验时间。
5. 内链与转化：确认真实 URL 后列出锚文本和插入段落；**每篇至少放置 2 个指向 PogoSkill 台湾站主页 `https://tw.pogoskill.com/` 的正文超链接**，使用不同自然锚文本并分布在有继续了解需求的段落。每篇都要有一段简洁、自然的 PogoSkill 产品推荐：先说明玩家痛点，再解释 location changer、路线模拟、Joystick、GPX 或 AutoCatch（仅在真实相关时）如何帮助当前场景；TOFU 文章可使用「如果你需要……」的可选过渡，但不能把产品写成参加活动的必要条件。不得堆裸 URL、不得硬插无关功能，也不得使用安全、零封号或不会被检测等绝对承诺。
6. Visual production pack：按文章结构规划实际需要的封面、原创信息图/表格、步骤截图、时间轴、地图/坐标、检查表和产品界面图。每张给出唯一编号、目的、插入段落、制作/拍摄说明、数据与图片来源、作者、许可、署名、台湾繁体图中文字、尺寸、jpg/webp、文件名、alt、caption 和压缩建议。核对站内旧图与产品当前版本。只使用自有、原创或许可明确素材；无授权则列「需授权/需拍摄」，不复制竞争站图片，不伪造界面。若图片尚未制作，正文仍必须保留对应的 Visual Placeholder，不能把占位当作已完成素材。
7. SEO/GEO：给出 40–60 字直接答案、关键事实表、定义块、FAQPage/Article/BreadcrumbList schema 建议；schema 内容必须与页面可见正文一致。提供作者简介、编辑政策或方法说明建议来增强信任。
8. Backlink suggestions：给出 5–10 个自然获链建议，例如值得制作的数据表、活动日历、原创统计、可嵌入工具或资源页，以及可能对此感兴趣的网站类型或真实页面。说明相关性和被引用的理由，但不生成联络名单或 outreach 草稿，不创建、提交、购买、交换、索取或联络链接，也不承诺获得链接。
9. 发布前审计：逐项执行 `seo-geo-checklist.md`，报告 PASS/WARN/FAIL；存在事实、版权或链接 FAIL 时不得称为可发布。

SEO 参考原则：Google Search Essentials/SEO Starter Guide 与 Google AI features guidance；GEO 参考 Semrush 的可引用、结构化、品牌/实体清晰原则；backlink 参考 Ahrefs 对高质量、相关、自然链接的定义。不得采用隐藏文本、门页、链接农场、付费传递排名链接或大规模低质 AI 页面。

## DOCX 正式交付与渲染 QA

从 2026-09-15 起，完成文章 Draft 后必须生成：

`runs/YYYY-MM-DD/topic-slug/04-article.docx`

生成前必须实际读取当前版本的 `04-draft.md`；DOCX 必须是该 Current Draft 的完整 Word 版本，包含正文所有章节、标题、表格、FAQ、CTA、来源、内链、至少 2 个指向 `https://tw.pogoskill.com/` 的主页超链接、Visual Placeholder、caption、alt、Editorial Notes、Fact Gaps 与审核状态。不得只生成摘要、提纲、Markdown 转存文件或旧 Draft 的 DOCX。

按 documents skill 使用 bundled Python/runtime 与 `render_docx.py` 渲染 DOCX 至页面 PNG；逐页检查，至少确认标题层级、段落分页、表格不溢出、中文字体不缺字、超链接/Visual Placeholder/来源未丢失、页面没有裁切或重叠。任何问题都必须修正并重新生成、重新渲染、重新检查。只有最新 Current Draft 对应的 DOCX 才能作为交付文件。

若 `05-review.md` 为 `PASS WITH FIXES` 或 `FAIL`，必须把完整 Review 交回 Writer，更新 Draft、重新生成 DOCX 并再次审核；DOCX 可以保存为审核稿，但不得标记 `Ready to Publish`。最终交付必须报告 DOCX 的绝对路径、当前 Draft 版本、渲染 QA 结果和最终审核状态。
