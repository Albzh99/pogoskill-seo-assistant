---
name: pogoskill-tw-seo
description: 為 PogoSkill 台灣站研究選題、查重、設計結構 Excel、撰寫並獨立審核 Pokémon GO 與 Pikmin Bloom 文章，或設定每日文章任務。適用於此站完整 SEO 文章流程，不代替其他網站的 CMS 規範。
---

以目前專案為工作目錄，路徑一律由專案推導。技能目錄可透過本 SKILL.md 定位。先讀 `references/AGENTS.md`（完整團隊規則）、`references/brand-memory.md`、`references/tw-content-style.md`、`references/internal-seo-standards.md` 和專案 `memory/learning/` 中與任務相關的資料。專案已有更新的同名規範時，以使用者明確更新的版本為準。

## 首次安裝與檢查

這是可安裝的工作流程技能；GitHub 下載本身不會建立每日任務。請閱讀倉庫 `README.md`，執行 `scripts/install.py` 建立獨立工作區，並以工作區的 Python 執行 `scripts/doctor.py`。歷史總帳 `PoGoskillTW-文章上线记录.xlsx` 必須由團隊提供最新版本，放在工作區根目錄；缺少總帳、必要工作表或原始結構模板時停止正式立項並回報，不能聲稱已完成查重。不得用示範資料代替總帳。

查重可使用 `scripts/read_ledger.py PoGoskillTW-文章上线记录.xlsx --output data/ledger.json` 讀取全部工作表、儲存格與超連結；這個只讀工具不載入可能不相容的 WPS 樣式，也不改動原始總帳。讀取輸出的完整 JSON，再選擇相關少量舊文核驗。數值日期需核對，公式只提供原檔儲存的快取值，不能當成重新計算結果。

## 選題與文章製作

僅研究時：讀 `references/daily-research-prompt.md` 的研究要求，交付 3–5 個經查重的 Proposal，等待使用者選題，不執行其中的「每日自主交付」。

使用者明確要求每日完整文章或自主選題時：讀完整 `references/daily-research-prompt.md`，已授權自主選擇唯一首選題，毋須每天再詢問選題。一天一篇可以是 UPDATE，不能強行 NEW PAGE。再讀 `references/article-production-prompt.md` 與 `references/seo-geo-checklist.md`。

依序完成研究 → 策略 → 架構 → 寫作 → 獨立審核 → 反思。各階段讀對應 `references/roles/` 的完整角色說明。在支援子代理的環境，本技能要求分派研究、策略、架構、寫作及獨立 Reviewer；主代理保存正式交接產物，下游實際讀檔，不靠聊天摘要。只有上游完成後才能進入下游。可用具名角色就使用具名角色，否則以一般子代理加載對應角色說明，不假設同事已安裝自訂角色。若環境不支援子代理，可以依角色分階段做研究和草稿，但必須回報缺少獨立審核、保留待審狀態，不得自行宣布獨立審核 PASS。

在 `runs/YYYY-MM-DD/topic-slug/` 完整保存：`01-research.md`、`02-seo-strategy.md`、`03-content-brief.md`、`03-article-structure.xlsx`、`04-draft.md`、`04-article.docx`、`05-review.md`、`06-reflection.md`。正式策略與 Brief 欄位、關鍵詞表、更新診斷、雙向內鏈、三欄 Excel 的實質內容及視覺方案，依完整團隊規則交付。

Writer 寫前必須實際讀完整 Brief 和結構 Excel；Reviewer 實際讀最新策略、Brief、Excel 和 Draft。PASS WITH FIXES 或 FAIL 必須交回完整審核、修稿並再審。可修正內容問題；缺事實、授權或工具時如實保留待審狀態，不捏造 PASS，不無限重試。

正文約 2,800–3,200 個中文字，資訊不足可縮短並說明；至少兩個自然正文連結到 `https://tw.pogoskill.com/`，並有承接玩家痛點的產品段與實際步驟。內鏈範圍依團隊規則，只用允許的首頁及 Guide／教學頁。核驗時效性事實、產品介面及功能；搜尋量／KD 無來源填「未取得」。

## 可攜式文件工具

安裝後用工作區 `.venv` 的 Python。`scripts/export_structure.py outline.json runs/.../03-article-structure.xlsx` 使用根目錄原始模板，JSON 是三欄非空字串的陣列；實際內容由 Architect 提供，工具不生成文章事實。`scripts/export_docx.py runs/.../04-draft.md` 完整轉換當前 Markdown，輸出同目錄 Word。只支援標題、段落、連結、粗體、清單和簡單表格；先檢查 Draft 是否含不支援的語法，必要時改善轉換工具後再交付，不得悄悄丟失內容。

原規則要求 documents skill 渲染。若同事環境有該技能，使用其渲染工具；若沒有，這份安裝包允許以 `scripts/render_docx.py` 搭配 LibreOffice 和 pdftoppm 輸出 PDF、逐頁 PNG 並人工視覺檢查，達成同一品質要求。兩者均不可用時，明確回報尚未完成視覺 QA，不得稱 Ready to Publish。程式成功或 ZIP 檢查通過不代表視覺 QA 通過。Draft 修改後重建 Word 並重新檢查。

## 每日任務

使用者要求設定時，讀 `docs/setup-daily.md`，透過當前 Codex 提供的自動任務工具建立在**同事目前帳號**與此工作區的每日 09:00（Asia/Taipei）任務。先查已有同用途任務，避免重複。這裡的 09:00 是啟動時間，完成後通知，不能保證瞬間交稿。若要 09:00 前交稿，需使用者另行授權提早啟動。保存的任務提示詞來自工作區 `automation-prompt.md`，替換工作區絕對路徑；模型沿用同事實際可用設定，不複製原作者模型、代理或憑證。原始排程檔不可直接複製到同事帳號。

最終回報標題、NEW／UPDATE、當前版本、審核狀態、Word／Excel 絕對路徑、視覺 QA、來源缺口。完成、失敗或需要使用者操作時通知；同一狀態不重複發送。僅在本機產出，未另行授權不得發佈 CMS 或寄信。
