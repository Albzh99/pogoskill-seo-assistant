"""Create a separate article workspace without touching account settings."""
import argparse
import shutil
import subprocess
import sys
import venv
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--ledger', type=Path, help='Latest private team ledger')
    parser.add_argument('--skip-deps', action='store_true', help='Use an existing runtime; no pip download')
    args = parser.parse_args()
    source = Path(__file__).resolve().parents[1]
    dest = args.workspace.expanduser().resolve()
    if dest.exists() and any(dest.iterdir()):
        parser.error('Workspace must be empty. Existing workspaces are never overwritten.')
    ledger = args.ledger.expanduser().resolve() if args.ledger else None
    if ledger and (not ledger.is_file() or ledger.suffix.lower() != '.xlsx'):
        parser.error('--ledger must be an existing .xlsx file')
    if source == dest or source in dest.parents or dest in source.parents:
        parser.error('Choose a workspace outside this installation repository')
    dest.mkdir(parents=True, exist_ok=True)
    for folder in ('.agents', 'scripts', 'docs'):
        shutil.copytree(source / folder, dest / folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for name in ('AGENTS.md', 'README.md', 'requirements.txt', 'automation-prompt.md', '.gitignore'):
        shutil.copy2(source / name, dest / name)
    skill = dest / '.agents/skills/pogoskill-tw-seo'
    for name in ('brand-memory.md', 'tw-content-style.md', 'internal-seo-standards.md',
                 'seo-geo-checklist.md', 'daily-research-prompt.md', 'article-production-prompt.md'):
        shutil.copy2(skill / 'references' / name, dest / name)
    shutil.copy2(skill / 'assets/繁中文章结构.xlsx', dest / '繁中文章结构.xlsx')
    (dest / 'memory/learning').mkdir(parents=True)
    shutil.copy2(skill / 'references/user-feedback.md', dest / 'memory/learning/user-feedback.md')
    shutil.copy2(skill / 'references/hypotheses.md', dest / 'memory/learning/hypotheses.md')
    shutil.copy2(skill / 'references/failure-patterns.md', dest / 'memory/learning/failure-patterns.md')
    (dest / 'runs').mkdir()
    if ledger:
        shutil.copy2(ledger, dest / 'PoGoskillTW-文章上线记录.xlsx')
    runtime = Path(sys.executable)
    if not args.skip_deps:
        venv.EnvBuilder(with_pip=True).create(dest / '.venv')
        runtime = dest / '.venv' / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
        subprocess.run([str(runtime), '-m', 'pip', 'install', '-r', str(dest / 'requirements.txt')], check=True)
    print('Workspace:', dest)
    print('Python:', runtime)
    print('Next: open this workspace in Codex, run scripts/doctor.py, then read docs/setup-daily.md.')
    print('No daily task has been created by this installer.')


if __name__ == '__main__':
    main()
