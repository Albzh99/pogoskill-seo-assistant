"""Check real local prerequisites; does not certify content review or scheduling."""
import importlib.util
import json
import shutil
import sys
from pathlib import Path

REQUIRED_SHEETS = ('SEO上线记录汇总（实时更新）', 'SEO优化记录',
                   '2026主题规划', '2025主题规划', '2024主题规划')


def main():
    root = Path(__file__).resolve().parents[1]
    checks = []
    def record(label, ok, required=True):
        checks.append({'check': label, 'ok': bool(ok), 'required': required})
    for module in ('openpyxl', 'docx'):
        record('Python module: ' + module, importlib.util.find_spec(module) is not None)
    for name in ('.agents/skills/pogoskill-tw-seo/SKILL.md', '繁中文章结构.xlsx', 'PoGoskillTW-文章上线记录.xlsx'):
        record(name, (root / name).is_file())
    ledger = root / 'PoGoskillTW-文章上线记录.xlsx'
    if ledger.is_file():
        from read_ledger import read_ledger
        try:
            parsed = read_ledger(ledger)
            names = {sheet['name'] for sheet in parsed['sheets']}
            for name in REQUIRED_SHEETS:
                record('Ledger sheet: ' + name, name in names)
        except Exception as error:
            record('Readable ledger: ' + str(error), False)
    soffice = shutil.which('soffice') or shutil.which('libreoffice')
    if not soffice and Path('/Applications/LibreOffice.app/Contents/MacOS/soffice').is_file():
        soffice = '/Applications/LibreOffice.app/Contents/MacOS/soffice'
    record('Fallback renderer: LibreOffice', soffice, False)
    record('Fallback renderer: pdftoppm', shutil.which('pdftoppm'), False)
    print(json.dumps({'workspace': str(root), 'checks': checks,
                      'manual_checks': ['Codex web search', 'Independent subagents', 'Chinese fonts and visual QA',
                                        'Current ledger freshness', 'Daily task exists in colleague account']}, ensure_ascii=False, indent=2))
    return 0 if all(c['ok'] for c in checks if c['required']) else 1


if __name__ == '__main__':
    sys.exit(main())
