"""Read actual XLSX cells/links without loading possibly malformed WPS styles.

Preserves cell references, raw cached values, formulas and hyperlink targets.
No formulas/macros are executed; source workbook is never rewritten.
"""
import argparse
import hashlib
import json
import posixpath
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
RID = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'


def relationship_path(base, target):
    result = posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join(base, target))
    if result.startswith('../'):
        raise ValueError('Invalid XLSX relationship path')
    return result


def read_ledger(path):
    with ZipFile(path) as archive:
        workbook = ET.fromstring(archive.read('xl/workbook.xml'))
        relationships = ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))
        targets = {r.attrib['Id']: relationship_path('xl', r.attrib['Target'])
                   for r in relationships if r.attrib.get('TargetMode') != 'External'}
        shared = []
        if 'xl/sharedStrings.xml' in archive.namelist():
            for node in ET.fromstring(archive.read('xl/sharedStrings.xml')).findall('m:si', NS):
                shared.append(''.join(t.text or '' for t in node.findall('.//m:t', NS)))
        sheets = []
        for sheet in workbook.findall('m:sheets/m:sheet', NS):
            target = targets[sheet.attrib[RID]]
            xml = ET.fromstring(archive.read(target))
            rows = []
            for row in xml.findall('m:sheetData/m:row', NS):
                cells = []
                for cell in row.findall('m:c', NS):
                    value_node = cell.find('m:v', NS)
                    value = value_node.text or '' if value_node is not None else ''
                    if cell.attrib.get('t') == 's' and value:
                        value = shared[int(value)]
                    elif cell.attrib.get('t') == 'inlineStr':
                        value = ''.join(n.text or '' for n in cell.findall('.//m:t', NS))
                    formula = cell.find('m:f', NS)
                    if value or formula is not None:
                        entry = {'cell': cell.attrib['r'], 'value': value, 'type': cell.attrib.get('t', 'n')}
                        if formula is not None:
                            entry['formula'] = formula.text or ''
                        cells.append(entry)
                if cells:
                    rows.append({'row': int(row.attrib['r']), 'cells': cells})
            links = []
            relfile = posixpath.join(posixpath.dirname(target), '_rels', posixpath.basename(target) + '.rels')
            link_targets = {}
            if relfile in archive.namelist():
                link_targets = {r.attrib['Id']: r.attrib['Target']
                                for r in ET.fromstring(archive.read(relfile))}
            for link in xml.findall('m:hyperlinks/m:hyperlink', NS):
                links.append({'cell': link.attrib['ref'],
                              'target': link_targets.get(link.attrib.get(RID), link.attrib.get('location', ''))})
            sheets.append({'name': sheet.attrib['name'], 'rows': rows, 'hyperlinks': links})
    return {'source': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'note': 'Values remain raw strings; numeric dates require explicit date conversion. Formula values are saved caches, not recalculated.',
            'sheets': sheets}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ledger', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve() == args.ledger.resolve():
        parser.error('Cannot overwrite source ledger')
    result = read_ledger(args.ledger)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'output': str(args.output.resolve()), 'sheets': [
        {'name': sheet['name'], 'rows': len(sheet['rows'])} for sheet in result['sheets']]}, ensure_ascii=False))
