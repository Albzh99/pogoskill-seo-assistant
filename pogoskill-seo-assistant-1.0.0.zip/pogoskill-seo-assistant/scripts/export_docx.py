"""Convert the entire current Markdown draft, including notes, links and tables."""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


def inline(paragraph, text):
    pattern = re.compile(r'\[([^\]]+)\]\((https?://[^\s)]+)\)|\*\*(.+?)\*\*')
    offset = 0
    for match in pattern.finditer(text):
        paragraph.add_run(text[offset:match.start()])
        if match.group(1):
            rid = paragraph.part.relate_to(match.group(2),
                'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', is_external=True)
            link = OxmlElement('w:hyperlink')
            link.set(qn('r:id'), rid)
            run = OxmlElement('w:r')
            props = OxmlElement('w:rPr')
            style = OxmlElement('w:rStyle')
            style.set(qn('w:val'), 'Hyperlink')
            props.append(style)
            run.append(props)
            node = OxmlElement('w:t')
            node.text = match.group(1)
            run.append(node)
            link.append(run)
            paragraph._p.append(link)
        else:
            paragraph.add_run(match.group(3)).bold = True
        offset = match.end()
    paragraph.add_run(text[offset:])


def export(draft, output, font):
    if draft.resolve() == output.resolve():
        raise ValueError('Cannot overwrite draft')
    raw = draft.read_bytes()
    lines = raw.decode('utf-8').splitlines()
    if any(re.match(r'^\s*(```|~~~|<table|<img|!\[)', line) for line in lines):
        raise ValueError('Draft contains code fences, HTML tables/images or embedded images; extend converter first.')
    doc = Document()
    section = doc.sections[0]
    section.left_margin = section.right_margin = Inches(.7)
    for name in ('Normal', 'Title', 'Heading 1', 'Heading 2', 'Heading 3', 'Heading 4'):
        style = doc.styles[name]
        style.font.name = font
        style.element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:eastAsia'), font)
    doc.styles['Normal'].font.size = Pt(11)
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line or re.fullmatch(r'[-*_]{3,}', line):
            i += 1
            continue
        if line.startswith('|'):
            block = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                cells = [v.strip() for v in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?', v) for v in cells):
                    block.append(cells)
                i += 1
            if len({len(row) for row in block}) != 1:
                raise ValueError('Table column mismatch; escaped pipes are unsupported')
            table = doc.add_table(rows=0, cols=len(block[0]))
            table.style = 'Table Grid'
            for row in block:
                for cell, value in zip(table.add_row().cells, row):
                    inline(cell.paragraphs[0], value)
            header = OxmlElement('w:tblHeader')
            table.rows[0]._tr.get_or_add_trPr().append(header)
            continue
        heading = re.match(r'^(#{1,6})\s+(.+)$', line)
        if heading:
            inline(doc.add_heading(level=len(heading.group(1))), heading.group(2))
        elif re.match(r'^[-*+]\s+', line):
            inline(doc.add_paragraph(style='List Bullet'), re.sub(r'^[-*+]\s+', '', line))
        elif re.match(r'^\d+\.\s+', line):
            inline(doc.add_paragraph(style='List Number'), re.sub(r'^\d+\.\s+', '', line))
        else:
            inline(doc.add_paragraph(), line)
        i += 1
    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)
    output.with_suffix('.build.json').write_text(json.dumps({
        'source': draft.name, 'source_sha256': hashlib.sha256(raw).hexdigest(),
        'docx_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'visual_qa': 'NOT_PERFORMED', 'content_review': 'See 05-review.md; exporter does not certify PASS'
    }, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('draft', type=Path)
    parser.add_argument('--output', type=Path)
    default_font = 'PingFang TC' if sys.platform == 'darwin' else ('Microsoft JhengHei' if sys.platform == 'win32' else 'Noto Sans CJK TC')
    parser.add_argument('--font', default=default_font, help='Install a zh-TW font available on your OS')
    args = parser.parse_args()
    output = args.output or args.draft.parent / '04-article.docx'
    export(args.draft, output, args.font)
    print(output.resolve())
