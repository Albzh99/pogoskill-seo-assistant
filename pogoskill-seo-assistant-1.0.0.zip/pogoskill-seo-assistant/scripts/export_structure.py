"""Write architect-provided three-column content into a copy of the real template."""
import argparse
import copy
import json
from pathlib import Path
from openpyxl import load_workbook


def export(source, output, template):
    rows = json.loads(source.read_text(encoding='utf-8'))
    if not isinstance(rows, list) or not rows or any(
        not isinstance(row, list) or len(row) != 3 or
        any(not isinstance(value, str) or not value.strip() or len(value) > 32767 for value in row)
        for row in rows
    ):
        raise ValueError('Input must be a nonempty list of [element, title, substantive content] strings.')
    if output.resolve() in (template.resolve(), source.resolve()):
        raise ValueError('Cannot overwrite the original template or source.')
    wb = load_workbook(template)
    ws = wb.active
    for merged in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(merged))
    for row in ws:
        for cell in row:
            cell.value = None
    data = [['Element Type', '標題 / Keyword / Question', 'SECTION CONTENT']] + rows
    for i, row in enumerate(data, 1):
        for j, value in enumerate(row, 1):
            cell = ws.cell(i, j)
            if i > 2:
                cell._style = copy.copy(ws.cell(2, j)._style)
            cell.value = value
            cell.data_type = 's'  # User content is text, never executable spreadsheet formulas.
            alignment = copy.copy(cell.alignment)
            alignment.wrap_text = True
            alignment.vertical = 'top'
            cell.alignment = alignment
        ws.row_dimensions[i].height = min(409, max(36, 15 * max(
            sum(max(1, (len(part) + width - 1) // width) for part in value.split('\n'))
            for value, width in zip(row, (12, 24, 56)))))
    for column, width in zip('ABC', (24, 42, 100)):
        ws.column_dimensions[column].width = width
    ws.freeze_panes = 'A2'
    ws.print_options.horizontalCentered = True
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.print_area = f'A1:C{len(data)}'
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--template', type=Path, default=Path(__file__).resolve().parents[1] / '繁中文章结构.xlsx')
    args = parser.parse_args()
    export(args.source, args.output, args.template)
    print(args.output.resolve())
