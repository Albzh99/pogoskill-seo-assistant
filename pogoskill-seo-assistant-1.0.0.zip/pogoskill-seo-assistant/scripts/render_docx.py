"""Fallback renderer. PNG creation does not perform visual QA."""
import argparse
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('document', type=Path)
    parser.add_argument('--font-dir', type=Path, action='append', default=[], help='Additional directory of installed CJK fonts')
    args = parser.parse_args()
    doc = args.document.resolve()
    if not doc.is_file() or doc.suffix.lower() != '.docx':
        parser.error('Existing .docx required')
    soffice = shutil.which('soffice') or shutil.which('libreoffice')
    mac = Path('/Applications/LibreOffice.app/Contents/MacOS/soffice')
    if not soffice and mac.is_file():
        soffice = str(mac)
    pdftoppm = shutil.which('pdftoppm')
    if not soffice or not pdftoppm:
        parser.error('Install LibreOffice and Poppler (pdftoppm), or use the available documents skill renderer. Visual QA remains incomplete.')
    out = doc.parent / (doc.stem + '-render')
    out.mkdir(exist_ok=True)
    # Each render gets a fresh directory, so obsolete pages cannot masquerade as current output.
    with tempfile.TemporaryDirectory(prefix='render-', dir=out) as temp:
        work = Path(temp)
        # Headless runtimes may not discover OS fonts or have a writable font cache.
        env = os.environ.copy()
        config = ET.Element('fontconfig')
        for default in ('/etc/fonts/fonts.conf', '/opt/homebrew/etc/fonts/fonts.conf'):
            ET.SubElement(config, 'include', {'ignore_missing': 'yes'}).text = default
        font_dirs = [Path('/System/Library/Fonts'), Path('/Library/Fonts'),
                     Path.home() / 'Library/Fonts', Path('/usr/share/fonts'),
                     Path.home() / '.local/share/fonts'] + args.font_dir
        assets = Path('/System/Library/AssetsV2')
        if assets.is_dir():
            font_dirs.extend(assets.glob('com_apple_MobileAsset_Font*/*.asset/AssetData'))
        if os.environ.get('WINDIR'):
            font_dirs.append(Path(os.environ['WINDIR']) / 'Fonts')
        for directory in font_dirs:
            if directory.is_dir():
                ET.SubElement(config, 'dir').text = str(directory.resolve())
        ET.SubElement(config, 'cachedir').text = str(work / 'font-cache')
        config_file = work / 'fonts.conf'
        ET.ElementTree(config).write(config_file, encoding='utf-8', xml_declaration=True)
        env['FONTCONFIG_FILE'] = str(config_file)
        env['XDG_CACHE_HOME'] = str(work / 'cache')
        subprocess.run([soffice, '-env:UserInstallation=' + (work / 'profile').as_uri(),
                        '--headless', '--convert-to', 'pdf', '--outdir', str(work), str(doc)], check=True, timeout=180, env=env)
        pdf = work / (doc.stem + '.pdf')
        if not pdf.is_file():
            raise RuntimeError('LibreOffice did not produce PDF')
        subprocess.run([pdftoppm, '-png', '-scale-to', '1600', str(pdf), str(work / 'page')], check=True, timeout=180, env=env)
        images = sorted(work.glob('page-*.png'))
        if not images:
            raise RuntimeError('Renderer produced no pages')
        final = Path(tempfile.mkdtemp(prefix='current-', dir=out))
        shutil.copy2(pdf, final / pdf.name)
        for image in images:
            shutil.copy2(image, final / image.name)
    print('Current render:', final)
    print('Inspect EVERY page image. Rendering alone does not imply visual QA or review PASS.')


if __name__ == '__main__':
    main()
